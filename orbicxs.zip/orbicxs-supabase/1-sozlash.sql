-- ============================================================================
-- OrbicXs — yopiq, ikki kishilik chat uchun Supabase sozlamasi (1/2: asosiy sozlash)
--
-- Qayerda: Supabase → SQL Editor → New query → shu faylni to'liq yopishtiring → Run.
-- Hech narsani tahrirlash shart emas. Qayta ishga tushirsangiz ham xavfsiz.
--
-- Eski chatning jadvallariga (messages, profiles, push_subscriptions) TEGILMAYDI:
-- yangilari "ox_" prefiksi bilan yaratiladi.
-- ============================================================================

create extension if not exists pg_net with schema extensions;

-- ---------- Jadvallar ----------

-- Chatga kirish huquqi bor ikki kishi (2-faylda to'ldiriladi)
create table if not exists public.ox_members (
  user_id  uuid primary key references auth.users(id) on delete cascade,
  added_at timestamptz not null default now()
);

create table if not exists public.ox_profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text not null check (char_length(btrim(name)) between 1 and 40),
  avatar_path text,
  updated_at  timestamptz not null default now()
);

-- Yagona xona, shuning uchun chat_id kerak emas. Yuboruvchi har doim tizimga
-- kirgan foydalanuvchi (auth.uid()), uni soxtalashtirib bo'lmaydi.
create table if not exists public.ox_messages (
  id         bigint generated always as identity primary key,
  sender_id  uuid not null default auth.uid() references auth.users(id) on delete cascade,
  body       text check (body is null or char_length(body) <= 4000),
  image_path text check (image_path is null or char_length(image_path) <= 300),
  created_at timestamptz not null default now(),
  constraint ox_messages_has_content
    check ((body is not null and btrim(body) <> '') or image_path is not null)
);

-- Push obunalari: brauzerga tegishli kalitlar. Faqat quyidagi funksiyalar orqali
create table if not exists public.ox_push (
  id           bigint generated always as identity primary key,
  user_id      uuid not null references auth.users(id) on delete cascade,
  endpoint     text not null unique,
  subscription jsonb not null,
  user_agent   text,
  updated_at   timestamptz not null default now()
);

-- ---------- "Chat a'zosimi?" tekshiruvi ----------

create or replace function public.ox_is_member()
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.ox_members m where m.user_id = (select auth.uid())
  );
$$;

revoke all on function public.ox_is_member() from public, anon;
grant execute on function public.ox_is_member() to authenticated;

-- ---------- Ruxsatlar (RLS) ----------

alter table public.ox_members  enable row level security;
alter table public.ox_profiles enable row level security;
alter table public.ox_messages enable row level security;
alter table public.ox_push     enable row level security;

-- Avval hamma ruxsatni olib tashlaymiz, keyin faqat keraklisini beramiz.
-- (ox_push ga hech kim to'g'ridan-to'g'ri tegmaydi, faqat pastdagi funksiyalar)
revoke all on public.ox_members, public.ox_profiles, public.ox_messages, public.ox_push
  from anon, authenticated;
grant select on public.ox_members to authenticated;
grant select, insert, update on public.ox_profiles to authenticated;
grant select, insert on public.ox_messages to authenticated;

drop policy if exists ox_members_self on public.ox_members;
create policy ox_members_self on public.ox_members
  for select to authenticated using (user_id = (select auth.uid()));

drop policy if exists ox_profiles_read on public.ox_profiles;
create policy ox_profiles_read on public.ox_profiles
  for select to authenticated using (public.ox_is_member());

drop policy if exists ox_profiles_insert on public.ox_profiles;
create policy ox_profiles_insert on public.ox_profiles
  for insert to authenticated
  with check (id = (select auth.uid()) and public.ox_is_member());

drop policy if exists ox_profiles_update on public.ox_profiles;
create policy ox_profiles_update on public.ox_profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

drop policy if exists ox_messages_read on public.ox_messages;
create policy ox_messages_read on public.ox_messages
  for select to authenticated using (public.ox_is_member());

drop policy if exists ox_messages_insert on public.ox_messages;
create policy ox_messages_insert on public.ox_messages
  for insert to authenticated
  with check (sender_id = (select auth.uid()) and public.ox_is_member());

-- ---------- Rasmlar uchun YOPIQ ombor (bucket) ----------
-- Fayllarga havola faqat tizimga kirgan a'zolarga, vaqtinchalik (signed URL) beriladi.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('ox-media', 'ox-media', false, 10485760, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = false,
      file_size_limit = 10485760,
      allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp'];

drop policy if exists ox_media_read on storage.objects;
create policy ox_media_read on storage.objects
  for select to authenticated
  using (bucket_id = 'ox-media' and public.ox_is_member());

drop policy if exists ox_media_insert on storage.objects;
create policy ox_media_insert on storage.objects
  for insert to authenticated
  with check (bucket_id = 'ox-media' and public.ox_is_member()
              and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists ox_media_update on storage.objects;
create policy ox_media_update on storage.objects
  for update to authenticated
  using (bucket_id = 'ox-media' and public.ox_is_member()
         and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'ox-media' and public.ox_is_member()
              and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists ox_media_delete on storage.objects;
create policy ox_media_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'ox-media' and public.ox_is_member()
         and (storage.foldername(name))[1] = (select auth.uid())::text);

-- ---------- Real vaqt (yangi xabar darhol keladi) ----------

do $$
begin
  alter publication supabase_realtime add table public.ox_messages;
exception when duplicate_object then
  null;  -- allaqachon qo'shilgan
end $$;

-- ---------- Push obunasini saqlash / o'chirish ----------

create or replace function public.ox_register_push(p_subscription jsonb, p_user_agent text default null)
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  v_endpoint text := p_subscription ->> 'endpoint';
begin
  if (select auth.uid()) is null or not public.ox_is_member() then
    raise exception 'ruxsat yo''q';
  end if;
  if v_endpoint is null or v_endpoint !~ '^https://' then
    raise exception 'push obunasi noto''g''ri';
  end if;

  insert into public.ox_push (user_id, endpoint, subscription, user_agent, updated_at)
  values ((select auth.uid()), v_endpoint, p_subscription, left(p_user_agent, 200), now())
  on conflict (endpoint) do update
    set user_id      = excluded.user_id,
        subscription = excluded.subscription,
        user_agent   = excluded.user_agent,
        updated_at   = now();
end $$;

create or replace function public.ox_unregister_push(p_endpoint text)
returns void
language sql security definer set search_path = ''
as $$
  delete from public.ox_push
  where endpoint = p_endpoint and user_id = (select auth.uid());
$$;

revoke all on function public.ox_register_push(jsonb, text) from public, anon;
revoke all on function public.ox_unregister_push(text) from public, anon;
grant execute on function public.ox_register_push(jsonb, text) to authenticated;
grant execute on function public.ox_unregister_push(text) to authenticated;

-- ---------- Yangi xabar kelganda push yuborish ----------
-- Trigger boshqa akkauntning obunalarini yig'adi va Edge Function'ga (send-push) uzatadi.
-- Push yuborishda xato bo'lsa ham xabarning o'zi baribir saqlanadi.

create or replace function public.ox_notify_message()
returns trigger
language plpgsql security definer set search_path = ''
as $$
declare
  v_name text;
  v_subs jsonb;
  v_text text;
begin
  -- 90 kundan beri ochilmagan qurilmalarning obunalarini tozalash
  delete from public.ox_push where updated_at < now() - interval '90 days';

  select jsonb_agg(p.subscription) into v_subs
    from public.ox_push p
    join public.ox_members m on m.user_id = p.user_id
   where p.user_id <> new.sender_id;

  if v_subs is null then
    return new;
  end if;

  select nullif(btrim(pr.name), '') into v_name
    from public.ox_profiles pr where pr.id = new.sender_id;

  v_text := case
    when new.body is not null and btrim(new.body) <> '' then left(btrim(new.body), 140)
    else '📷 Rasm'
  end;

  perform net.http_post(
    url     := 'https://osicrbckwwgoybnlhmrh.supabase.co/functions/v1/send-push',
    headers := jsonb_build_object(
      'Content-Type',     'application/json',
      'Authorization',    'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9zaWNyYmNrd3dnb3libmxobXJoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUxODE0OTgsImV4cCI6MjA4MDc1NzQ5OH0.FFncYlnJwNklYdM3inCiZn3HATjQXpL5VbFmHxrjipw',
      'x-webhook-secret', 'TyQ_7u5G4cp_FgyG6s3pQSnkLttadult'
    ),
    body    := jsonb_build_object(
      'title',         coalesce(v_name, 'OrbicXs'),
      'body',          v_text,
      'url',           './',
      'subscriptions', v_subs
    )
  );
  return new;
exception when others then
  raise warning 'ox_notify_message: %', sqlerrm;
  return new;
end $$;

revoke all on function public.ox_notify_message() from public, anon, authenticated;

drop trigger if exists ox_messages_notify on public.ox_messages;
create trigger ox_messages_notify
  after insert on public.ox_messages
  for each row execute function public.ox_notify_message();
