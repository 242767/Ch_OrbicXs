-- ============================================================================
-- OrbicXs — chatga kiradigan IKKI kishini belgilash (2/2)
--
-- Tartib:
--   1) Supabase → Authentication → Users → "Add user" → "Create new user":
--      ikkala akkauntni yarating ("Auto Confirm User" ni yoqing).
--   2) Pastdagi ikki emailni o'zingizniki bilan almashtiring (KICHIK harflarda).
--   3) SQL Editor'da ishga tushiring.
--
-- Bu ro'yxatdagilardan boshqa hech kim xabarlarni o'qiy olmaydi va yoza olmaydi.
-- ============================================================================

begin;

insert into public.ox_members (user_id)
select id from auth.users
where lower(email) in (
  'birinchi@gmail.com',
  'ikkinchi@gmail.com'
)
on conflict do nothing;

-- Tekshiruv: 1 yoki 2 ta a'zo bo'lishi kerak (0 bo'lsa, emaillar mos kelmagan).
-- Xato chiqsa, yuqoridagi qo'shish ham bekor bo'ladi.
do $$
declare n int;
begin
  select count(*) into n from public.ox_members;
  if n = 0 then
    raise exception 'Hech kim topilmadi. Emaillarni tekshiring: ular Authentication → Users dagi bilan bir xil bo''lsin.';
  elsif n > 2 then
    raise exception 'A''zolar % ta. Chat faqat ikki kishi uchun mo''ljallangan.', n;
  end if;
end $$;

commit;

select u.email as chatga_kiradiganlar, m.added_at
from public.ox_members m
join auth.users u on u.id = m.user_id
order by m.added_at;
