-- ============================================================================
-- OrbicXs — ESKI (hamma uchun ochiq) chatni tozalash.  IXTIYORIY.
--
-- OGOHLANTIRISH: eski xabarlar, profillar va push obunalari BUTUNLAY o'chadi,
-- qaytarib bo'lmaydi. Quyidagi shartlar bajarilsagina ishga tushiring:
--   • eski chatdagi yozishmalar sizga kerak emas;
--   • bu Supabase loyihasida "messages", "profiles", "push_subscriptions"
--     jadvallarini ishlatadigan boshqa ilova yo'q.
--
-- Nega kerak: eski jadvallarda ruxsatlar ochiq qolgan bo'lishi mumkin, ya'ni
-- anon kalit bilan (u index.html ichida ochiq turadi) har kim eski xabarlarni
-- o'qiy olishi mumkin. Yangi chat (ox_*) bunga bog'liq emas, lekin eskisini
-- tozalagan ma'qul.
--
-- Eski RASMLAR ham tozalanishi kerak, ular SQL bilan o'chmaydi:
--   Supabase → Storage → "chat-images" va "avatars" omborlarini o'chiring
--   (ular ochiq edi, havolasi borlar hamon ochib ko'ra oladi).
-- ============================================================================

drop table if exists public.messages cascade;
drop table if exists public.push_subscriptions cascade;
drop table if exists public.profiles cascade;
